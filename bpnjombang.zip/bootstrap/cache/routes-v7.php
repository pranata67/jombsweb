<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wSkdJn6Qhvm0ZcQn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ySJc3dqCsR9yZGGG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/wa-bot' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'wa-bot-test',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uJar1sV3GliJMhoH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/account' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pbfqlJBhWLcp3cYR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9HI0IQCJrmyi2WKB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/form-petugas-lapang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ibkXNfauTxnyO31P',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/surat-petugas-lapang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8f59ctp7tgADRNdT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/detail-catatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jnsfEQ7HHDZCT0Y4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/form-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l7OuP1ZazsyKiwYS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/form-kerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OF0Cb6SuGntDCimh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/registrasi-dikerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aQWkamZ1F3RCmHRp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/registrasi-dikembalikan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BsKUreE7q1cqT37r',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QayV76866ngoMu3k',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/petugas-lapang-validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LDk0iAgqSfaIuLnY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cek-petugas-permohonan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vedsbMymWCUuP50S',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/kecamatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SR3koZbj7VgAnlGc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/desa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fZauTnFTBzxg8ivz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
            'POST' => 2,
            'PUT' => 3,
            'PATCH' => 4,
            'DELETE' => 5,
            'OPTIONS' => 6,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/uri-tes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PGMFxczqE3lgIDap',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/rand-string' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ybrWToDMjtGMeFpg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getProvinsi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'getProvinsi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getKabupaten' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'getKabupaten',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getKecamatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'getKecamatan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/getDesa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'getDesa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/import-permohonan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'import-permohonan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/do-login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'do-login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'forgot-password',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'send-email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/send-email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-ulang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reset-ulang-password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/service-unavailable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'service-unavailable',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/link-reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WFwA6Leswcak3z2G',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/data-lapangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dataLapangan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cek-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cekStatusPermohonanDashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/cek-petugas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cekPetugasPermohonanDashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/store-permohonan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-permohonan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/form-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/detail-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'detail-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/save-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'save-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/delete-gambar-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-gambar-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/delete-sertifikat-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-sertifikat-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/delete-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/export-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'export-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/sync' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'syncronUserPetugasPermohonan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/sync-by-id' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'syncronUserPetugasPermohonanByID',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/datail-catatan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'datail-catatan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/show-pindahkan-berkas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'show-pindahkan-berkas',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/get-petugas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'get-petugas',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/store-pindahkan-berkas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-pindahkan-berkas',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/kerjakan/form-kerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-kerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/kerjakan/kerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'kerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/kerjakan/tutup-kerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tutup-kerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/kerjakan/tolak-kerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tolak-kerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi/kerjakan/delete-file-validasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-file-validasi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/validasi-bidang/validasi-bidang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'validasi-bidang',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/validasi-bidang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-validasi-bidang',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-dikerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-registrasi-dikerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-dikerjakan/form-registrasi-dikerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-registrasi-dikerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-dikerjakan/detail-registrasi-dikerjakan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'detail-registrasi-dikerjakan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-dikerjakan/get-petugas-terakhir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'get-petugas-terakhir',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-ditolak' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-registrasi-ditolak',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-ditolak/export' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'export-registrasi-ditolak',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-dikembalikan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-registrasi-dikembalikan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/registrasi-selesai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-registrasi-selesai',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keperluan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-keperluan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keperluan/form-keperluan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-keperluan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keperluan/store-keperluan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-keperluan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/keperluan/delete-keperluan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-keperluan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/operator-bpn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-operator-bpn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/operator-bpn/form-operator-bpn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-operator-bpn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/operator-bpn/store-operator-bpn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-operator-bpn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/operator-bpn/delete-operator-bpn' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-operator-bpn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-verifikator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-verifikator',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-verifikator/form-petugas-verifikator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-verifikator',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-verifikator/store-petugas-verifikator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-verifikator',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-verifikator/delete-petugas-verifikator' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-verifikator',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-lapangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-lapangan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-lapangan/form-petugas-lapangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-lapangan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-lapangan/store-petugas-lapangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-lapangan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-lapangan/delete-petugas-lapangan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-lapangan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-pemetaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-pemetaan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-pemetaan/form-petugas-pemetaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-pemetaan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-pemetaan/store-petugas-pemetaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-pemetaan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-pemetaan/delete-petugas-pemetaan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-pemetaan',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-su-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-su-el',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-su-el/form-petugas-su-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-su-el',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-su-el/store-petugas-su-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-su-el',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-su-el/delete-petugas-su-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-su-el',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-bt-el',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt-el/form-petugas-bt-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-bt-el',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt-el/store-petugas-bt-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-bt-el',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt-el/delete-petugas-bt-el' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-bt-el',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-bt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt/form-petugas-bt' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-bt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt/store-petugas-bt' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-bt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-bt/delete-petugas-bt' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-bt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-petugas-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-registrasi/form-petugas-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-petugas-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-registrasi/store-petugas-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-petugas-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/petugas-registrasi/delete-petugas-registrasi' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-petugas-registrasi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengaturan' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-pengaturan',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengaturan/update-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'update-password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pengaturan/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'reset-password',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/re(?|set\\-ulang\\-password/([^/]++)(*:42)|gistrasi/surat\\-petugas\\-lapang/([^/]++)(*:89))|/pendaftaran/(?|([^/]++)(*:121)|store(*:134)|cek\\-no\\-sertifikat(*:161)))/?$}sDu',
    ),
    3 => 
    array (
      42 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'form-reset-ulang-password',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      89 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'surat-lapangan',
          ),
          1 => 
          array (
            0 => 'id_permohonan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      121 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'main-pendaftaran',
          ),
          1 => 
          array (
            0 => 'kode_acak',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      134 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'store-pendaftaran',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      161 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'cek-no-sertifikat',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::wSkdJn6Qhvm0ZcQn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::wSkdJn6Qhvm0ZcQn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ySJc3dqCsR9yZGGG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000004440000000000000000";}";s:4:"hash";s:44:"W8jFSLqAjuYx/RqiWl/yBQlfW6mTijqqmH3qTS/3FC8=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ySJc3dqCsR9yZGGG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'wa-bot-test' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/wa-bot',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Webhook\\WebhookController@chatBot',
        'controller' => 'App\\Http\\Controllers\\Webhook\\WebhookController@chatBot',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'wa-bot-test',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uJar1sV3GliJMhoH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiLoginController@doLogin',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiLoginController@doLogin',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::uJar1sV3GliJMhoH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pbfqlJBhWLcp3cYR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/account',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiLoginController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiLoginController@updatePassword',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::pbfqlJBhWLcp3cYR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9HI0IQCJrmyi2WKB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::9HI0IQCJrmyi2WKB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ibkXNfauTxnyO31P' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/form-petugas-lapang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@formSuratLapangan',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@formSuratLapangan',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ibkXNfauTxnyO31P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8f59ctp7tgADRNdT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/surat-petugas-lapang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@suratlapangan',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@suratlapangan',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8f59ctp7tgADRNdT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jnsfEQ7HHDZCT0Y4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/detail-catatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@detailCatatan',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@detailCatatan',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::jnsfEQ7HHDZCT0Y4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l7OuP1ZazsyKiwYS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/form-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@form',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@form',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::l7OuP1ZazsyKiwYS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OF0Cb6SuGntDCimh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/form-kerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiKerjakanPermohonanController@kerjakanForm',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiKerjakanPermohonanController@kerjakanForm',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::OF0Cb6SuGntDCimh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aQWkamZ1F3RCmHRp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/registrasi-dikerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikerjakanController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikerjakanController@index',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::aQWkamZ1F3RCmHRp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BsKUreE7q1cqT37r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/registrasi-dikembalikan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikembalikanController@getPermohonanDikembalikan',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikembalikanController@getPermohonanDikembalikan',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::BsKUreE7q1cqT37r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QayV76866ngoMu3k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikerjakanController@getPermohonanValidasi',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikerjakanController@getPermohonanValidasi',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::QayV76866ngoMu3k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LDk0iAgqSfaIuLnY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/petugas-lapang-validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikerjakanController@savePermohonanValidasi',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanDikerjakanController@savePermohonanValidasi',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::LDk0iAgqSfaIuLnY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vedsbMymWCUuP50S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/cek-petugas-permohonan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@cekPetugasPermohonan',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiPermohonanController@cekPetugasPermohonan',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::vedsbMymWCUuP50S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SR3koZbj7VgAnlGc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/kecamatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiKecamatanController@getKecamatan',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiKecamatanController@getKecamatan',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::SR3koZbj7VgAnlGc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fZauTnFTBzxg8ivz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
        2 => 'POST',
        3 => 'PUT',
        4 => 'PATCH',
        5 => 'DELETE',
        6 => 'OPTIONS',
      ),
      'uri' => 'api/desa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\ApiDesaController@getDesa',
        'controller' => 'App\\Http\\Controllers\\Api\\ApiDesaController@getDesa',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::fZauTnFTBzxg8ivz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PGMFxczqE3lgIDap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'uri-tes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:2139:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1919:"function () {

    // $link = $shortener->shorten(new Url(\'https://github.com/andrzejkupczyk/url-shortener\'));

    // print($link->shortUrl()); // http://bit.ly/2Dkm8SJ
    // $apiUri = \'http://103.187.215.99/bpn_mojokerto/public/pendaftaran\';
    // $apiKey = \'e6071e4883a6d23098dbd356511ef0ca7cf52f00\';
    // $shortener = UrlShortener::bitly($apiUri, $apiKey);
    // $Uri = $shortener->shorten(new Url(\'https://github.com/andrzejkupczyk/url-shortener\'));
    // $randPermohonan = mt_rand(1000000, 9999999);
    // $randPermohonan = rand(10000, 99999);
    // return $randPermohonan;
    // return date("H:i:s", time());
    // $data = KodeRegistrasi::select(DB::raw(\'DATE(created_at) as tanggal\'), \'no_hp\', DB::raw(\'COUNT(*) as total\'))
    // ->groupBy(\'tanggal\', \'no_hp\')
    // ->get();
    // return $data;
    $file = \\App\\Models\\Permohonan::select(\'file_sertifikat\')->whereNotNull(\'file_sertifikat\')->get();
    try {
        $data = \\App\\Models\\User::select(\'id\',\'name\')->where(\'level_user\',2)->with([\'permohonan_user_lapang:petugas_lapang_id,petugas_pengukuran,status_pengukuran\'])->get();
        // $data = App\\Models\\Permohonan::where(\'file_sertifikat\', \'pakta integritas ulil.pdf\')->get();
        // $duplicates = App\\Models\\Permohonan::select(\'file_sertifikat\')
        //     ->groupBy(\'file_sertifikat\')
        //     ->havingRaw(\'COUNT(file_sertifikat) > 1\')
        //     ->pluck(\'file_sertifikat\');

        // $data = App\\Models\\Permohonan::whereIn(\'file_sertifikat\', $duplicates)->get();
        // $data = App\\Models\\Permohonan::select(\'file_sertifikat\')
        //     ->groupBy(\'file_sertifikat\')
        //     ->havingRaw(\'COUNT(file_sertifikat) > 1\')
        //     ->get();
        return \\count($data);
        return \\response()->json($data);
    } catch(\\Exception $e) {
        return \\response()->json([\'message\' => $e->getMessage()]);
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000004580000000000000000";}";s:4:"hash";s:44:"SHl2WQXGZKff6jgi9kD1Usqs4rLSgW+3iudaPPXHyQc=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PGMFxczqE3lgIDap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ybrWToDMjtGMeFpg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rand-string',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Webhook\\WebhookController@generateSimpleRandomString',
        'controller' => 'App\\Http\\Controllers\\Webhook\\WebhookController@generateSimpleRandomString',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ybrWToDMjtGMeFpg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'getProvinsi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getProvinsi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@getProvinsi',
        'controller' => 'App\\Http\\Controllers\\DashboardController@getProvinsi',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'getProvinsi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'getKabupaten' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getKabupaten',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@getKabupaten',
        'controller' => 'App\\Http\\Controllers\\DashboardController@getKabupaten',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'getKabupaten',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'getKecamatan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getKecamatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@getKecamatan',
        'controller' => 'App\\Http\\Controllers\\DashboardController@getKecamatan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'getKecamatan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'getDesa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'getDesa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@getDesa',
        'controller' => 'App\\Http\\Controllers\\DashboardController@getDesa',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'getDesa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'import-permohonan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'import-permohonan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@importPermohonanExcel',
        'controller' => 'App\\Http\\Controllers\\DashboardController@importPermohonanExcel',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'import-permohonan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'do-login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'do-login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@doLogin',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@doLogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'do-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'forgot-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@forgotPassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@forgotPassword',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'forgot-password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'send-email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@sendEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@sendEmail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'send-email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'send-email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@sendEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@sendEmail',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-reset-ulang-password' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-ulang-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@resetPassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@resetPassword',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'form-reset-ulang-password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reset-ulang-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-ulang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@resetUlangPassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@resetUlangPassword',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'reset-ulang-password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-pendaftaran' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pendaftaran/{kode_acak}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@index',
        'controller' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@index',
        'namespace' => NULL,
        'prefix' => '/pendaftaran',
        'where' => 
        array (
        ),
        'as' => 'main-pendaftaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-pendaftaran' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pendaftaran/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@store',
        'controller' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@store',
        'namespace' => NULL,
        'prefix' => '/pendaftaran',
        'where' => 
        array (
        ),
        'as' => 'store-pendaftaran',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cek-no-sertifikat' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pendaftaran/cek-no-sertifikat',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@cekNoSertifikat',
        'controller' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@cekNoSertifikat',
        'namespace' => NULL,
        'prefix' => '/pendaftaran',
        'where' => 
        array (
        ),
        'as' => 'cek-no-sertifikat',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'service-unavailable' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'service-unavailable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@serviceUnavailable',
        'controller' => 'App\\Http\\Controllers\\Pendaftaran\\PendaftaranValidasiController@serviceUnavailable',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'service-unavailable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WFwA6Leswcak3z2G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'link-reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:299:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:81:"function () {
    return \\view(\'auth.forgot-password.link-toreset-password\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000046c0000000000000000";}";s:4:"hash";s:44:"oRR3FI+VV6nPozo+/qgEWG068pnKBI7P2CvYPtmUI0A=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WFwA6Leswcak3z2G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dataLapangan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'data-lapangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@dataLapangan',
        'controller' => 'App\\Http\\Controllers\\DashboardController@dataLapangan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dataLapangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cekStatusPermohonanDashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cek-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@cekStatusPermohonan',
        'controller' => 'App\\Http\\Controllers\\DashboardController@cekStatusPermohonan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cekStatusPermohonanDashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'cekPetugasPermohonanDashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'cek-petugas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\DashboardController@cekPetugasPermohonan',
        'controller' => 'App\\Http\\Controllers\\DashboardController@cekPetugasPermohonan',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'cekPetugasPermohonanDashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-permohonan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'store-permohonan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Webhook\\WebhookController@store',
        'controller' => 'App\\Http\\Controllers\\Webhook\\WebhookController@store',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'store-permohonan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@index',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@index',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'main-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/form-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@form',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@form',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'form-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'detail-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/detail-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@detail',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@detail',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'detail-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'save-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/save-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@save',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@save',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'save-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-gambar-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'registrasi/delete-gambar-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@deleteGambar',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@deleteGambar',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'delete-gambar-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-sertifikat-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'registrasi/delete-sertifikat-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@deleteSertif',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@deleteSertif',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'delete-sertifikat-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'registrasi/delete-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@delete',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@delete',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'delete-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'export-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/export-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@export',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@export',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'export-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'syncronUserPetugasPermohonan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/sync',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@syncronUserPetugasPermohonan',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@syncronUserPetugasPermohonan',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'syncronUserPetugasPermohonan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'syncronUserPetugasPermohonanByID' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/sync-by-id',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@syncronUserPetugasPermohonanByID',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@syncronUserPetugasPermohonanByID',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'syncronUserPetugasPermohonanByID',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'surat-lapangan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/surat-petugas-lapang/{id_permohonan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@suratlapangan',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@suratlapangan',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'surat-lapangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'datail-catatan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/datail-catatan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@detailCatatan',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@detailCatatan',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'datail-catatan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'show-pindahkan-berkas' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi/show-pindahkan-berkas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@showPindahBerkas',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@showPindahBerkas',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'show-pindahkan-berkas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'get-petugas' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/get-petugas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@getPetugasByLevelUser',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@getPetugasByLevelUser',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'get-petugas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-pindahkan-berkas' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/store-pindahkan-berkas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanController@storePindahkanBerkas',
        'controller' => 'App\\Http\\Controllers\\PermohonanController@storePindahkanBerkas',
        'namespace' => NULL,
        'prefix' => '/registrasi',
        'where' => 
        array (
        ),
        'as' => 'store-pindahkan-berkas',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-kerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/kerjakan/form-kerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KerjakanPermohonanController@kerjakanForm',
        'controller' => 'App\\Http\\Controllers\\KerjakanPermohonanController@kerjakanForm',
        'namespace' => NULL,
        'prefix' => 'registrasi/kerjakan',
        'where' => 
        array (
        ),
        'as' => 'form-kerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'kerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/kerjakan/kerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KerjakanPermohonanController@kerjakan',
        'controller' => 'App\\Http\\Controllers\\KerjakanPermohonanController@kerjakan',
        'namespace' => NULL,
        'prefix' => 'registrasi/kerjakan',
        'where' => 
        array (
        ),
        'as' => 'kerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tutup-kerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/kerjakan/tutup-kerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KerjakanPermohonanController@tutupKerjakan',
        'controller' => 'App\\Http\\Controllers\\KerjakanPermohonanController@tutupKerjakan',
        'namespace' => NULL,
        'prefix' => 'registrasi/kerjakan',
        'where' => 
        array (
        ),
        'as' => 'tutup-kerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tolak-kerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'registrasi/kerjakan/tolak-kerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KerjakanPermohonanController@tolakKerjakan',
        'controller' => 'App\\Http\\Controllers\\KerjakanPermohonanController@tolakKerjakan',
        'namespace' => NULL,
        'prefix' => 'registrasi/kerjakan',
        'where' => 
        array (
        ),
        'as' => 'tolak-kerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-file-validasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi/kerjakan/delete-file-validasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KerjakanPermohonanController@deleteFileValidasi',
        'controller' => 'App\\Http\\Controllers\\KerjakanPermohonanController@deleteFileValidasi',
        'namespace' => NULL,
        'prefix' => 'registrasi/kerjakan',
        'where' => 
        array (
        ),
        'as' => 'delete-file-validasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'validasi-bidang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'validasi-bidang/validasi-bidang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ValidasiBidangController@index',
        'controller' => 'App\\Http\\Controllers\\ValidasiBidangController@index',
        'namespace' => NULL,
        'prefix' => '/validasi-bidang',
        'where' => 
        array (
        ),
        'as' => 'validasi-bidang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-validasi-bidang' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'validasi-bidang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\ValidasiBidangController@mainValidasiBidang',
        'controller' => 'App\\Http\\Controllers\\ValidasiBidangController@mainValidasiBidang',
        'namespace' => NULL,
        'prefix' => '/validasi-bidang',
        'where' => 
        array (
        ),
        'as' => 'main-validasi-bidang',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-registrasi-dikerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi-dikerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@index',
        'controller' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@index',
        'namespace' => NULL,
        'prefix' => '/registrasi-dikerjakan',
        'where' => 
        array (
        ),
        'as' => 'main-registrasi-dikerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-registrasi-dikerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi-dikerjakan/form-registrasi-dikerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@form',
        'controller' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@form',
        'namespace' => NULL,
        'prefix' => '/registrasi-dikerjakan',
        'where' => 
        array (
        ),
        'as' => 'form-registrasi-dikerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'detail-registrasi-dikerjakan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'registrasi-dikerjakan/detail-registrasi-dikerjakan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@detail',
        'controller' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@detail',
        'namespace' => NULL,
        'prefix' => '/registrasi-dikerjakan',
        'where' => 
        array (
        ),
        'as' => 'detail-registrasi-dikerjakan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'get-petugas-terakhir' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi-dikerjakan/get-petugas-terakhir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@getUpdateTerakhir',
        'controller' => 'App\\Http\\Controllers\\PermohonanDikerjakanController@getUpdateTerakhir',
        'namespace' => NULL,
        'prefix' => '/registrasi-dikerjakan',
        'where' => 
        array (
        ),
        'as' => 'get-petugas-terakhir',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-registrasi-ditolak' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi-ditolak',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDitolakController@index',
        'controller' => 'App\\Http\\Controllers\\PermohonanDitolakController@index',
        'namespace' => NULL,
        'prefix' => '/registrasi-ditolak',
        'where' => 
        array (
        ),
        'as' => 'main-registrasi-ditolak',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'export-registrasi-ditolak' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi-ditolak/export',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDitolakController@export',
        'controller' => 'App\\Http\\Controllers\\PermohonanDitolakController@export',
        'namespace' => NULL,
        'prefix' => '/registrasi-ditolak',
        'where' => 
        array (
        ),
        'as' => 'export-registrasi-ditolak',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-registrasi-dikembalikan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi-dikembalikan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanDikembalikanController@index',
        'controller' => 'App\\Http\\Controllers\\PermohonanDikembalikanController@index',
        'namespace' => NULL,
        'prefix' => '/registrasi-dikembalikan',
        'where' => 
        array (
        ),
        'as' => 'main-registrasi-dikembalikan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-registrasi-selesai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'registrasi-selesai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PermohonanSelesaiDikerjakanController@index',
        'controller' => 'App\\Http\\Controllers\\PermohonanSelesaiDikerjakanController@index',
        'namespace' => NULL,
        'prefix' => '/registrasi-selesai',
        'where' => 
        array (
        ),
        'as' => 'main-registrasi-selesai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-keperluan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'keperluan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KeperluanController@index',
        'controller' => 'App\\Http\\Controllers\\KeperluanController@index',
        'namespace' => NULL,
        'prefix' => '/keperluan',
        'where' => 
        array (
        ),
        'as' => 'main-keperluan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-keperluan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'keperluan/form-keperluan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KeperluanController@form',
        'controller' => 'App\\Http\\Controllers\\KeperluanController@form',
        'namespace' => NULL,
        'prefix' => '/keperluan',
        'where' => 
        array (
        ),
        'as' => 'form-keperluan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-keperluan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'keperluan/store-keperluan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KeperluanController@store',
        'controller' => 'App\\Http\\Controllers\\KeperluanController@store',
        'namespace' => NULL,
        'prefix' => '/keperluan',
        'where' => 
        array (
        ),
        'as' => 'store-keperluan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-keperluan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'keperluan/delete-keperluan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\KeperluanController@destroy',
        'controller' => 'App\\Http\\Controllers\\KeperluanController@destroy',
        'namespace' => NULL,
        'prefix' => '/keperluan',
        'where' => 
        array (
        ),
        'as' => 'delete-keperluan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-operator-bpn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'operator-bpn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\OperatorBPNController@index',
        'controller' => 'App\\Http\\Controllers\\OperatorBPNController@index',
        'namespace' => NULL,
        'prefix' => '/operator-bpn',
        'where' => 
        array (
        ),
        'as' => 'main-operator-bpn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-operator-bpn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'operator-bpn/form-operator-bpn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\OperatorBPNController@form',
        'controller' => 'App\\Http\\Controllers\\OperatorBPNController@form',
        'namespace' => NULL,
        'prefix' => '/operator-bpn',
        'where' => 
        array (
        ),
        'as' => 'form-operator-bpn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-operator-bpn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'operator-bpn/store-operator-bpn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\OperatorBPNController@store',
        'controller' => 'App\\Http\\Controllers\\OperatorBPNController@store',
        'namespace' => NULL,
        'prefix' => '/operator-bpn',
        'where' => 
        array (
        ),
        'as' => 'store-operator-bpn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-operator-bpn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'operator-bpn/delete-operator-bpn',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\OperatorBPNController@destroy',
        'controller' => 'App\\Http\\Controllers\\OperatorBPNController@destroy',
        'namespace' => NULL,
        'prefix' => '/operator-bpn',
        'where' => 
        array (
        ),
        'as' => 'delete-operator-bpn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-verifikator' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-verifikator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasVerifikatorController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasVerifikatorController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-verifikator',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-verifikator',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-verifikator' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-verifikator/form-petugas-verifikator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasVerifikatorController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasVerifikatorController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-verifikator',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-verifikator',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-verifikator' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-verifikator/store-petugas-verifikator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasVerifikatorController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasVerifikatorController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-verifikator',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-verifikator',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-verifikator' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-verifikator/delete-petugas-verifikator',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasVerifikatorController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasVerifikatorController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-verifikator',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-verifikator',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-lapangan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-lapangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasLapanganController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasLapanganController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-lapangan',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-lapangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-lapangan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-lapangan/form-petugas-lapangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasLapanganController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasLapanganController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-lapangan',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-lapangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-lapangan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-lapangan/store-petugas-lapangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasLapanganController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasLapanganController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-lapangan',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-lapangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-lapangan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-lapangan/delete-petugas-lapangan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasLapanganController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasLapanganController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-lapangan',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-lapangan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-pemetaan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-pemetaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasPemetaanController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasPemetaanController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-pemetaan',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-pemetaan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-pemetaan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-pemetaan/form-petugas-pemetaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasPemetaanController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasPemetaanController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-pemetaan',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-pemetaan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-pemetaan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-pemetaan/store-petugas-pemetaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasPemetaanController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasPemetaanController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-pemetaan',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-pemetaan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-pemetaan' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-pemetaan/delete-petugas-pemetaan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasPemetaanController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasPemetaanController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-pemetaan',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-pemetaan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-su-el' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-su-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasSUELController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasSUELController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-su-el',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-su-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-su-el' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-su-el/form-petugas-su-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasSUELController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasSUELController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-su-el',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-su-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-su-el' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-su-el/store-petugas-su-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasSUELController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasSUELController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-su-el',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-su-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-su-el' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-su-el/delete-petugas-su-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasSUELController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasSUELController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-su-el',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-su-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-bt-el' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-bt-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTELController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasBTELController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-bt-el',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-bt-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-bt-el' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-bt-el/form-petugas-bt-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTELController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasBTELController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-bt-el',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-bt-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-bt-el' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-bt-el/store-petugas-bt-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTELController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasBTELController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-bt-el',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-bt-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-bt-el' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-bt-el/delete-petugas-bt-el',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTELController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasBTELController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-bt-el',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-bt-el',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-bt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-bt',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasBTController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-bt',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-bt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-bt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-bt/form-petugas-bt',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasBTController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-bt',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-bt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-bt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-bt/store-petugas-bt',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasBTController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-bt',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-bt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-bt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-bt/delete-petugas-bt',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasBTController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasBTController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-bt',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-bt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-petugas-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'petugas-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasRegistrasiController@index',
        'controller' => 'App\\Http\\Controllers\\PetugasRegistrasiController@index',
        'namespace' => NULL,
        'prefix' => '/petugas-registrasi',
        'where' => 
        array (
        ),
        'as' => 'main-petugas-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'form-petugas-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-registrasi/form-petugas-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasRegistrasiController@form',
        'controller' => 'App\\Http\\Controllers\\PetugasRegistrasiController@form',
        'namespace' => NULL,
        'prefix' => '/petugas-registrasi',
        'where' => 
        array (
        ),
        'as' => 'form-petugas-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'store-petugas-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-registrasi/store-petugas-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasRegistrasiController@store',
        'controller' => 'App\\Http\\Controllers\\PetugasRegistrasiController@store',
        'namespace' => NULL,
        'prefix' => '/petugas-registrasi',
        'where' => 
        array (
        ),
        'as' => 'store-petugas-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-petugas-registrasi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'petugas-registrasi/delete-petugas-registrasi',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PetugasRegistrasiController@destroy',
        'controller' => 'App\\Http\\Controllers\\PetugasRegistrasiController@destroy',
        'namespace' => NULL,
        'prefix' => '/petugas-registrasi',
        'where' => 
        array (
        ),
        'as' => 'delete-petugas-registrasi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'main-pengaturan' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'pengaturan',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PengaturanController@index',
        'controller' => 'App\\Http\\Controllers\\PengaturanController@index',
        'namespace' => NULL,
        'prefix' => '/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'main-pengaturan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'update-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pengaturan/update-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PengaturanController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\PengaturanController@updatePassword',
        'namespace' => NULL,
        'prefix' => '/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'update-password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'reset-password' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pengaturan/reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\PengaturanController@resetPw',
        'controller' => 'App\\Http\\Controllers\\PengaturanController@resetPw',
        'namespace' => NULL,
        'prefix' => '/pengaturan',
        'where' => 
        array (
        ),
        'as' => 'reset-password',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
