var sertifikatUpload = $('#file_sertifikat')
var sertifikatPreview = $('.sertifikat-preview')

var validSertif = [];
//upload sertif
sertifikatUpload.change((e)=>{
    let files = e.target.files;
    
    validSertif = Array.from(files);
    sertifikatPreview.html('');

    for (let i = 0; i < files.length; i++) {
        let file = validSertif[i];
        let picReader = new FileReader();

        picReader.addEventListener('load', (e) => {
            var picFile = e.target;
            let isImage = file.type.startsWith('image/');
            let isPDF = file.type === 'application/pdf';
            let sertifContainer = $(`
            <div class="sertif-container" data-index="${i}" style="display: flex; justify-content: space-between;">
                <p style="margin:0">${isImage || isPDF ? `<a href="javascript:void(0);" class="view-btn" data-file-index="${i}">${file.name}</a>` : `${file.name}`}</p>
                <a href="javascript:void(0);" class="remove-btn remove">Hapus</a>
            </div>
            `)

            sertifikatPreview.append(sertifContainer);
        });
        picReader.readAsDataURL(file);
    };

})

sertifikatPreview.on('click', '.remove', function() {
    let sertifContainer = $(this).closest('.sertif-container');
    let index = sertifContainer.data('index');

    validSertif.splice(index, 1);

    sertifikatUpload[0].files = new SertifListItems(validSertif);

    sertifContainer.remove();

    $('.sertif-container').each(function(i, elem) {
        $(elem).attr('data-index', i);
    });
});

sertifikatPreview.on('click', '.view-btn', function() {
  let index = $(this).data('file-index');
  let file = validSertif[index];
  let isImage = file.type.startsWith('image/');
  let isPDF = file.type === 'application/pdf';
  
  let reader = new FileReader();
  reader.onload = function(e) {
    let fileWindow = window.open("", "_blank");
    
    if (fileWindow) {
      if (isImage) {
        fileWindow.document.write(`<img src="${e.target.result}" alt="Image Preview">`);
      } else if (isPDF) {
        fileWindow.document.write(`<iframe src="${e.target.result}" width="100%" height="100%" style="border:none;"></iframe>`);
      }
    } else {
      alert("Jendela pop-up diblokir oleh browser. Silakan izinkan pop-up.");
    }
  };
  
  if (isImage) {
    reader.readAsDataURL(file); // Gambar diproses sebagai Data URL
  } else if (isPDF) {
    reader.readAsDataURL(file); // PDF diproses sebagai Data URL
  }
});

function SertifListItems(files) {
    const b = new DataTransfer();
    for (let i = 0; i < files.length; i++) {
        b.items.add(files[i]);
    }
    return b.files;
}