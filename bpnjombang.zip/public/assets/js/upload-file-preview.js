var imagesUpload = $('#images-upload')
var imagesPreview = $('.images-preview')

var validFiles = [];
//upload gambar
imagesUpload.change((e)=>{
    let files = e.target.files;

    validFiles = Array.from(files);
    imagesPreview.html('');

    for (let i = 0; i < files.length; i++) {
        let file = validFiles[i];
        let picReader = new FileReader();

        picReader.addEventListener('load', (e) => {
            var picFile = e.target;
            let isImage = file.type.startsWith('image/');
            let isPDF = file.type === 'application/pdf';
            let imgContainer = $(`
            <div class="img-container" data-index="${i}" style="display: flex; justify-content: space-between;">
                <p style="margin:0">${isImage || isPDF ? `<a href="javascript:void(0);" class="view-btn" data-file-index="${i}">${file.name}</a>` : `${file.name}`}</p>
                <a href="javascript:void(0);" class="remove-btn remove">Hapus</a>
            </div>
            `)

            imagesPreview.append(imgContainer);
        });
        picReader.readAsDataURL(file);
    };

})

imagesPreview.on('click', '.remove', function() {
    let imgContainer = $(this).closest('.img-container');
    let index = imgContainer.data('index');

    validFiles.splice(index, 1);

    imagesUpload[0].files = new FileListItems(validFiles);

    imgContainer.remove();

    $('.img-container').each(function(i, elem) {
        $(elem).attr('data-index', i);
    });
});

imagesPreview.on('click', '.view-btn', function() {
    let index = $(this).data('file-index');
    let file = validFiles[index];
    let isImage = file.type.startsWith('image/');
    let isPDF = file.type === 'application/pdf';
    
    let reader = new FileReader();
    reader.onload = function(e) {
    let fileWindow = window.open("", "_blank");
    
    if (fileWindow) {
        if (isImage) {
        fileWindow.document.write(`<img src="${e.target.result}" alt="Image Preview">`);
        } else if (isPDF) {
        fileWindow.document.write(`<iframe src="${e.target.result}" width="100%" height="100%" style="border:none;"></iframe>`);
        }
    } else {
        alert("Jendela pop-up diblokir oleh browser. Silakan izinkan pop-up.");
    }
    };
    
    if (isImage) {
    reader.readAsDataURL(file); // Gambar diproses sebagai Data URL
    } else if (isPDF) {
    reader.readAsDataURL(file); // PDF diproses sebagai Data URL
    }
});

function FileListItems(files) {
    const b = new DataTransfer();
    for (let i = 0; i < files.length; i++) {
        b.items.add(files[i]);
    }
    return b.files;
}