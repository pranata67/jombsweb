<?php

namespace App\Repositories\PetugasKembali;

class PetugasKembaliRepository
{
    public function __construct()
    {

    }
}
