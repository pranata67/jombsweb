<table>
    <thead style="background-color: #279273">
        <tr role="row">
            <th style="border: 1px solid #000; font-weight: bold;">No. Regis</th>
            <th style="border: 1px solid #000; font-weight: bold;">Tgl.Permohonan</th>
            <th style="border: 1px solid #000; font-weight: bold;">Nama Pemohon</th>
            <th style="border: 1px solid #000; font-weight: bold;">Telp.Pemohon</th>
            <th style="border: 1px solid #000; font-weight: bold;">Sertipikat</th>
            <th style="border: 1px solid #000; font-weight: bold;">Desa</th>
            <th style="border: 1px solid #000; font-weight: bold;">Kecamatan</th>
            <th style="border: 1px solid #000; font-weight: bold;">Jenis Pemetaan</th>
            <th style="border: 1px solid #000; font-weight: bold;">Proses Lapangan</th>
            <th style="border: 1px solid #000; font-weight: bold;">Status Pemetaan</th>
            <th style="border: 1px solid #000; font-weight: bold;">Status SUEL</th>
            <th style="border: 1px solid #000; font-weight: bold;">Status BTEL</th>
            <th style="border: 1px solid #000; font-weight: bold;">Status Akhir</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border: 1px solid #000;"><?php echo e($item->no_permohonan); ?></td>
            <td style="border: 1px solid #000;"><?php echo e(\Carbon\Carbon::parse($item->tgl_input)->isoFormat('DD/MM/YYYY')); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->nama_pemohon); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->telepon_pemohon); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->no_sertifikat); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->desa_nama); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->kecamatan_nama); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->jenis_pemetaan); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->status_pengukuran); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->status_pemetaan); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->status_su_el); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->status_bt_el); ?></td>
            <td style="border: 1px solid #000;"><?php echo e($item->status_permohonan); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\PROJECT\BPN_MOKER_NEW\resources\views\permohonan\excel.blade.php ENDPATH**/ ?>