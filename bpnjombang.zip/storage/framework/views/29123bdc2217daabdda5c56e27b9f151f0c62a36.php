<?php if(Auth::user()->level_user == '12' || Auth::user()->level_user == '5'): ?>
    <nav id="sidebar" aria-label="Main Navigation" style="background-color: #000">
<?php else: ?>
    <nav id="sidebar" aria-label="Main Navigation">
<?php endif; ?>
<!-- Side Header -->
<?php if(Auth::user()->level_user == '12' || Auth::user()->level_user == '5'): ?>
    <div class="bg-header-darks" style="background-color: #d9361c">
        <div class="content-header bg-white-5">
        <!-- Logo -->
        <a class="fw-semibold text-white tracking-wide">
            <span class="">BPN - Kab. JOMBANG</span>
        </a>
        <!-- END Logo -->
        </div>
    </div>
<?php else: ?>
    <div class="bg-header-dark">
        <div class="content-header bg-white-5">
        <!-- Logo -->
        <a class="fw-semibold text-white tracking-wide">
            <span class="">BPN - Kab. JOMBANG</span>
        </a>
        <!-- END Logo -->
        </div>
    </div>
<?php endif; ?>
<!-- END Side Header -->

<!-- Sidebar Scrolling -->
<div class="js-sidebar-scrolls">
    <!-- Side Navigation -->
    <div class="content-side">
        <ul class="nav-main">
            <li class="nav-main-heading">Menu Utama</li>
            <li class="nav-main-item">
                <a class="nav-main-link <?php echo e($data['menuActive'] == 'dashboard' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                    <i class="nav-main-link-icon fa fa-gauge"></i>
                    <span class="nav-main-link-name">Dashboard</span>
                    
                </a>
            </li>
            <li class="nav-main-heading">Pengaturan Halaman</li>
                <li class="nav-main-item">
                    <a class="nav-main-link <?php echo e($data['menuActive'] == 'registrasi' ? 'active' : ''); ?>" href="<?php echo e(route('main-registrasi')); ?>">
                        <i class="nav-main-link-icon fa fa-people-group"></i>
                        <span class="nav-main-link-name">Data Register</span>
                    </a>
                </li>
                
                
                <?php if(Auth::user()->level_user == '1'): ?>
                <li class="nav-main-item">
                    <a
                    class="nav-main-link
                    <?php echo e($data['menuActive'] == 'registrasi-dikerjakan' ? 'active' : ''); ?>

                    "
                    href="<?php echo e(route('main-registrasi-dikerjakan')); ?>"
                    >
                        <i class="nav-main-link-icon fa fa-people-group"></i>
                        <span class="nav-main-link-name">Register Diproses</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '11'): ?> 
                    <li class="nav-main-item">
                        <a
                        class="nav-main-link
                        <?php echo e($data['menuActive'] == 'registrasi-ditolak' ? 'active' : ''); ?>

                        "
                        href="<?php echo e(route('main-registrasi-ditolak')); ?>"
                        >
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Register Ditolak</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->level_user == '2'): ?>
                    <li class="nav-main-item">
                        <a
                        class="nav-main-link
                        <?php echo e($data['menuActive'] == 'validasi-bidang' ? 'active' : ''); ?>

                        "
                        href="<?php echo e(route('main-validasi-bidang')); ?>"
                        >
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Validasi Bidang</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->level_user == '11' || Auth::user()->level_user == '3' || Auth::user()->level_user == '2'): ?> 
                <li class="nav-main-item">
                    <a
                    class="nav-main-link
                    <?php echo e($data['menuActive'] == 'registrasi-dikembalikan' ? 'active' : ''); ?>

                    "
                    href="<?php echo e(route('main-registrasi-dikembalikan')); ?>"
                    >
                        <i class="nav-main-link-icon fa fa-people-group"></i>
                        <span class="nav-main-link-name">Berkas Kembali</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if(Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '11'): ?>
                    <li class="nav-main-item">
                        <a
                        class="nav-main-link
                        <?php echo e($data['menuActive'] == 'petugas-verifikator' ? 'active' : ''); ?>

                        "
                        href="<?php echo e(route('main-petugas-verifikator')); ?>"
                        >
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Petugas Verifikator</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '3'): ?>
                    <li class="nav-main-item">
                        <a class="nav-main-link <?php echo e($data['menuActive'] == 'pemetaan' ? 'active' : ''); ?>" href="<?php echo e(route('main-petugas-pemetaan')); ?>">
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Petugas Pemetaan</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if( Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '2'): ?> 
                    <li class="nav-main-item">
                        <a class="nav-main-link <?php echo e($data['menuActive'] == 'petugas-lapang' ? 'active' : ''); ?>" href="<?php echo e(route('main-petugas-lapangan')); ?>">
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Petugas Lapang</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '4' ): ?>
                    <li class="nav-main-item">
                        <a class="nav-main-link <?php echo e($data['menuActive'] == 'petugas-su-el' ? 'active' : ''); ?>" href="<?php echo e(route('main-petugas-su-el')); ?>">
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Petugas SU EL</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->level_user == '10' || Auth::user()->level_user == '5' || Auth::user()->level_user == '12'): ?>
                    <li class="nav-main-item">
                        <a class="nav-main-link <?php echo e($data['menuActive'] == 'registrasi-selesai' ? 'active' : ''); ?>" href="<?php echo e(route('main-registrasi-selesai')); ?>">
                            <i class="nav-main-link-icon fa fa-people-group"></i>
                            <span class="nav-main-link-name">Sudah Dikerjakan</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(#Auth::user()->level_user == '5' ||
                Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '5'): ?>
                    
                <?php endif; ?>
                <?php if(#Auth::user()->level_user == '5' ||
                Auth::user()->level_user == '1' || Auth::user()->level_user == '10' || Auth::user()->level_user == '12'): ?>
                    
                <?php endif; ?>
                
                    
                
                <li class="nav-main-item">
                    <a class="nav-main-link <?php echo e($data['menuActive'] == 'pengaturan' ? 'active' : ''); ?>" href="<?php echo e(route('main-pengaturan')); ?>">
                        <i class="nav-main-link-icon fa fa-gears"></i>
                        <span class="nav-main-link-name">Pengaturan</span>
                    </a>
                </li>
        </ul>
    </div>
    <!-- END Side Navigation -->
</div>
<!-- END Sidebar Scrolling -->
</nav>
<?php /**PATH C:\PROJECT\BPN_MOKER_NEW\resources\views\layouts\sidebar.blade.php ENDPATH**/ ?>