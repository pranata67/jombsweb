<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">

    <title>BPN | Forgot Password</title>

    <meta name="description" content="Dashmix - Bootstrap 5 Admin Template &amp; UI Framework created by pixelcave">
    <meta name="author" content="pixelcave">
    <meta name="robots" content="index, follow">

    <!-- Open Graph Meta -->
    <meta property="og:title" content="Dashmix - Bootstrap 5 Admin Template &amp; UI Framework">
    <meta property="og:site_name" content="Dashmix">
    <meta property="og:description" content="Dashmix - Bootstrap 5 Admin Template &amp; UI Framework created by pixelcave">
    <meta property="og:type" content="website">
    <meta property="og:url" content="">
    <meta property="og:image" content="">

    <!-- Icons -->
    <!-- The following icons can be replaced with your own, they are used by desktop and mobile browsers -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/logobpn.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/media/favicons/favicon-192x192.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/media/favicons/apple-touch-icon-180x180.png">
    <!-- END Icons -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" id="css-main" href="<?php echo e(asset('assets/css/dashmix.min.css')); ?>">
  </head>

  <body>
    <div id="page-container">

      <!-- Main Container -->
      <main id="main-container">
        <!-- Page Content -->
        <div class="bg-image" style="background-image: url('<?php echo e(asset('assets/img/kantor_bpn.png')); ?>');">
          <div class="row g-0 justify-content-center bg-primary-dark-op">
            <div class="hero-static col-sm-8 col-md-6 col-xl-4 d-flex align-items-center p-2 px-sm-0">
              <!-- Sign In Block -->
              <div class="block block-transparent block-rounded w-100 mb-0 overflow-hidden">
                <div class="block-content block-content-full px-lg-4 px-xl-5 py-3 py-md-4 py-lg-5 bg-body-extra-light">
                  <!-- Header -->
                  <div class="mb-1 text-center">
                    <img src="<?php echo e(asset('assets/img/logobpn.png')); ?>" width="120" height="120" alt="">
                    <p class="text-uppercase fw-bold fs-lg mt-3 lh-1">BADAN PERTANAHAN NASIONAL <br>KABUPATEN JOMBANG</p>
                    <p class="text-uppercase fw-bold fs-sm text-muted">Reset Password</p>
                  </div>
                  
                    
                    
                  <!-- END Sign In Form -->
                </div>
                <div class="block-content bg-body">
                    <div class="d-flex justify-content-center text-center ">
                        <p class="fs-xs">Jl. KH. Wahid Hasyim Jl. Tugu Utara No.112, Tugu, Kepatihan, Kec. Jombang, Kabupaten Jombang, Jawa Timur 61419</p>
                    </div>
                </div>
              </div>
              <!-- END Sign In Block -->
            </div>
          </div>
        </div>
        <!-- END Page Content -->
      </main>
      <!-- END Main Container -->
    </div>
    <!-- END Page Container -->

    <!--
      Dashmix JS

      Core libraries and functionality
      webpack is putting everything together at assets/_js/main/app.js
    -->
    <script src="<?php echo e(asset('assets/js/dashmix.app.min.js')); ?>"></script>

    <!-- jQuery (required for jQuery Validation plugin) -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

    <!-- Page JS Plugins -->
    <script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>

    <!-- Page JS Code -->
    <script src="<?php echo e(asset('assets/js/op_auth_signin.min.js')); ?>"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
    
  </body>
</html>
<?php /**PATH C:\PROJECT\BPN_MOKER_NEW\resources\views\auth\forgot-password\reset.blade.php ENDPATH**/ ?>